function contrasenyes() {
    var contrasenya1 = document.getElementById("contrasenya1").value;

    var contrasenya2 = document.getElementById("contrasenya2").value;

    if (contrasenya1 == contrasenya2) {
        alert("Les contrasenyes coincideixen");
    } else {
        alert("Les contrasenyes no coincideixen");
    }

}