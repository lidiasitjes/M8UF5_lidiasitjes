//Llum apagat
function canviaImatge(elem) {
    elem.style.backgroundImage = "url(llumon.gif)"
}

//Llum trencat
function trencaImatge(elem) {
    elem.style.backgroundImage = "url(llumbreak.gif)"
}

//Llum encés
function tornaImatge(elem) {
    elem.style.backgroundImage = "url(llumoff.gif)"
}