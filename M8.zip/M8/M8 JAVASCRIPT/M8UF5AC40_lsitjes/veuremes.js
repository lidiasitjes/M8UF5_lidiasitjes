//Veure més text
function veureMes() {

    //Veure text extra
    var desplegar = document.getElementById("mestext");
    desplegar.style.display = "inline";

    //Ocultar enllaç
    var ocultar = document.getElementById("link");
    ocultar.style.display = "none";
}